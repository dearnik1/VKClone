# VKClone
Web client for vk.com using vk API.
My first educational project.